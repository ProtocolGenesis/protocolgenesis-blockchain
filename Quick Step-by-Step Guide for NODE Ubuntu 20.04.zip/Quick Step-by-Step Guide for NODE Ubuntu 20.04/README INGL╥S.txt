Quick Installation Guide for the ProtocolGenesis Node

Simply copy the setup_protocolgenesis file into your root directory on an Ubuntu 20.04 server and run the following commands:

Command to grant permission and execute the script:


Comando para da permição e executar o prompt:


chmod +x setup_protocolgenesis.sh && ./setup_protocolgenesis.sh


The script will download and install all the dependencies required to run the node quickly and easily.