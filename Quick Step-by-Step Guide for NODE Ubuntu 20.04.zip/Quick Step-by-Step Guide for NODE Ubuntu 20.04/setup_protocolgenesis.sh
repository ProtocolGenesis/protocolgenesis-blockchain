##!/bin/bash

# Updates the system
sudo apt update
sudo apt upgrade -y

# Installs the necessary dependencies
sudo apt-get install -y build-essential autoconf libtool pkg-config libboost-all-dev libssl-dev libprotobuf-dev protobuf-compiler libevent-dev qtbase5-dev qttools5-dev-tools libcanberra-gtk-module libdb++-dev

# Downloads and configures Berkeley DB
wget http://download.oracle.com/berkeley-db/db-4.8.30.NC.tar.gz
tar -xvf db-4.8.30.NC.tar.gz
sudo chmod -R 775 db-4.8.30.NC
cd db-4.8.30.NC/build_unix

# Modify the atomic.h file after extracting Berkeley DB
ATOMIC_H_FILE="/root/db-4.8.30.NC/dbinc/atomic.h"

# Checks if the atomic.h file exists and replaces its content
if [ -f "$ATOMIC_H_FILE" ]; then
    echo "Replacing the content of $ATOMIC_H_FILE..."
    cat <<EOL | sudo tee "$ATOMIC_H_FILE" > /dev/null
#ifndef _DB_ATOMIC_H_
#define _DB_ATOMIC_H_

#if defined(__cplusplus)
extern "C" {
#endif

#if defined(DB_WIN32)
typedef DWORD atomic_value_t;
#else
typedef int32_t atomic_value_t;
#endif

#if defined(DB_WINCE)
typedef struct {
    volatile atomic_value_t value;
    volatile atomic_value_t dummy;
} db_atomic_t;
#else
typedef struct {
    volatile atomic_value_t value;
} db_atomic_t;
#endif

#define atomic_read(p) ((p)->value)
#define atomic_init(p, val) ((p)->value = (val))

#ifdef HAVE_ATOMIC_SUPPORT

#if defined(DB_WIN32)
#if defined(DB_WINCE)
#define WINCE_ATOMIC_MAGIC(p) (p)->dummy = 0
#else
#define WINCE_ATOMIC_MAGIC(p) 0
#endif

#if defined(DB_WINCE) || (defined(_MSC_VER) && _MSC_VER < 1300)
typedef PLONG interlocked_val;
#define atomic_inc(env, p) \
    (WINCE_ATOMIC_MAGIC(p), InterlockedIncrement((interlocked_val)(&(p)->value)))
#else
typedef LONG volatile *interlocked_val;
#define atomic_inc(env, p) \
    InterlockedIncrement((interlocked_val)(&(p)->value))
#endif

#define atomic_dec(env, p) \
    (WINCE_ATOMIC_MAGIC(p), InterlockedDecrement((interlocked_val)(&(p)->value)))

#if defined(_MSC_VER) && _MSC_VER < 1300
#define atomic_compare_exchange(env, p, oldval, newval) \
    (WINCE_ATOMIC_MAGIC(p), \
     (InterlockedCompareExchange((PVOID *)(&(p)->value), (PVOID)(newval), (PVOID)(oldval)) == (PVOID)(oldval)))
#else
#define atomic_compare_exchange(env, p, oldval, newval) \
    (WINCE_ATOMIC_MAGIC(p), \
     (InterlockedCompareExchange((interlocked_val)(&(p)->value), (newval), (oldval)) == (oldval)))
#endif
#endif

#if defined(HAVE_ATOMIC_SOLARIS)
#include <atomic.h>
#define atomic_inc(env, p) \
    atomic_inc_uint_nv((volatile unsigned int *) &(p)->value)
#define atomic_dec(env, p) \
    atomic_dec_uint_nv((volatile unsigned int *) &(p)->value)
#define atomic_compare_exchange(env, p, oval, nval) \
    (atomic_cas_32((volatile unsigned int *) &(p)->value, (oval), (nval)) == (oval))
#endif

#if defined(HAVE_ATOMIC_X86_GCC_ASSEMBLY)
#define atomic_inc(env, p) __atomic_inc(p)
#define atomic_dec(env, p) __atomic_dec(p)
#define atomic_compare_exchange(env, p, o, n) custom_atomic_compare_exchange((p), (o), (n))

static inline int __atomic_inc(db_atomic_t *p) {
    int temp = 1;
    __asm__ __volatile__("lock; xadd %0, (%1)" : "+r"(temp) : "r"(p));
    return (temp + 1);
}

static inline int __atomic_dec(db_atomic_t *p) {
    int temp = -1;
    __asm__ __volatile__("lock; xadd %0, (%1)" : "+r"(temp) : "r"(p));
    return (temp - 1);
}

static inline int custom_atomic_compare_exchange(db_atomic_t *p, atomic_value_t oldval, atomic_value_t newval) {
    atomic_value_t was;
    if (p->value != oldval)
        return 0;
    __asm__ __volatile__("lock; cmpxchgl %1, (%2);" : "=a"(was) : "r"(newval), "r"(p), "a"(oldval) : "memory", "cc");
    return (was == oldval);
}
#endif

#else

#ifndef HAVE_MUTEX_SUPPORT
#define atomic_inc(env, p) (++(p)->value)
#define atomic_dec(env, p) (--(p)->value)
#define atomic_compare_exchange(env, p, oldval, newval) \
    (atomic_read(p) == (oldval) ? (atomic_init(p, (newval)), 1) : 0)
#else
#define atomic_inc(env, p) __atomic_inc(env, p)
#define atomic_dec(env, p) __atomic_dec(env, p)
#endif

#endif

#if defined(__cplusplus)
}
#endif

#endif /* !_DB_ATOMIC_H_ */
EOL
fi

# Proceeds with the configuration of Berkeley DB
mkdir -p build
BDB_PREFIX=$(pwd)/build
../dist/configure --disable-shared --enable-cxx --with-pic --prefix=$BDB_PREFIX
sudo make install

# Downloads the protocolgenesis.zip file directly to the /root directory
wget https://github.com/ProtocolGenesis/protocolgenesis-blockchain/raw/abf351692a70efa93ebea890aefb00f3433738bb/protocolgenesis.zip -P /root

# Extracts the file in the /root directory
unzip /root/protocolgenesis.zip -d /root
sudo chmod -R 755 /root/protocolgenesis
cd /root/protocolgenesis

# Compiles the source code
./autogen.sh
./configure CPPFLAGS="-I${BDB_PREFIX}/include/ -O2" LDFLAGS="-L${BDB_PREFIX}/lib/"
make -j$(nproc)

# Configures the firewall
sudo ufw enable
sudo ufw allow 22,80,443,8080,6333,16335,16444,8333,6667,8545,3001,9333,3008/tcp
sudo ufw allow out 22,80,443,8080,6333,16335,16444,8333,6667,8545,3001,9333,3008/tcp

# Creates the .protocolgenesis directory
mkdir -p ~/.protocolgenesis

# Configures the server IP
SERVER_IP=$(hostname -I | awk '{print $1}')
if [[ -z "$SERVER_IP" ]]; then
    echo "Error: Unable to determine the server IP."
    exit 1
fi

# Creates the protocolgenesis.conf file
cat <<EOL > ~/.protocolgenesis/protocolgenesis.conf
rpcuser=ecentrldWhiteKnightTheojrThefuture36377
rpcpassword=3242fy0j94A453648452Aky
txindex=1
rpcallowip=127.0.0.1
daemon=1
rpcport=6332
port=6333
maxconnections=125
listen=1
discover=1
dnsseed=1
upnp=1
addnode=185.101.104.97
addnode=194.113.64.152
addnode=195.200.0.158
addnode=109.110.184.26
addnode=$SERVER_IP
EOL

echo "Configuration created successfully with server IP: $SERVER_IP."

# Updates packages and installs mlocate
sudo apt update
sudo apt install mlocate -y

# Starts the node
/root/protocolgenesis/src/protocolgenesisd
sleep 15

# Updates the file database
sudo updatedb

# Blockchain synchronization
while true; do
    blocks=$(/root/protocolgenesis/src/protocolgenesis-cli getblockchaininfo | grep '"blocks"' | awk '{print $2}' | tr -d ',')
    headers=$(/root/protocolgenesis/src/protocolgenesis-cli getblockchaininfo | grep '"headers"' | awk '{print $2}' | tr -d ',')
    if [[ "$blocks" -eq "$headers" ]]; then
        echo "Synchronization complete! Blocks: $blocks, Headers: $headers."
        break
    else
        echo "Synchronizing... Blocks: $blocks, Headers: $headers. Checking again in 10 seconds."
        sleep 10
    fi
done

# Generates a new address
/root/protocolgenesis/src/protocolgenesis-cli getnewaddress

# Displays balance
/root/protocolgenesis/src/protocolgenesis-cli getbalance

# Displays info
/root/protocolgenesis/src/protocolgenesis-cli getinfo

# Final message
echo "Your ProtocolGenesis node is ready!"

# Final message
echo ""
echo "--------------------"
echo "Parabens! Seu node da ProtocolGenesis foi criado! Agora voce faz parte do ecossistema."
echo "Portugues: Parabens, seu node da ProtocolGenesis foi criado! Agora voce faz parte do ecossistema."
echo "No node voce pode gerenciar carteiras, fazer transacoes, monitorar a rede e conectar a API diretamente ao app ProtocolGenesis."
echo "Vamos juntos revolucionar o mundo com descentralizacao, liberdade e fraternidade!"
echo ""
echo "English: Congratulations! Your ProtocolGenesis node has been created. Now you are part of the ecosystem."
echo "On the node, you can manage wallets, make transactions, monitor the network, and connect APIs directly to the ProtocolGenesis app."
echo "Together, we will revolutionize the world with decentralization, freedom, and fraternity!"
echo ""
echo "Espanol: Felicidades! Su nodo de ProtocolGenesis ha sido creado. Ahora es parte del ecosistema."
echo "En el nodo, puede gestionar carteras, realizar transacciones, monitorear la red y conectar API directamente a la aplicacion de ProtocolGenesis."
echo "Juntos revolucionaremos el mundo con descentralizacion, libertad y fraternidad!"
echo ""
echo "Francais: Felicitations ! Votre noeud ProtocolGenesis a ete cree. Vous faites maintenant partie de l'ecosysteme."
echo "Sur le noeud, vous pouvez gerer des portefeuilles, effectuer des transactions, surveiller le reseau et connecter directement les API a l'application ProtocolGenesis."
echo "Ensemble, nous revolutionnerons le monde avec decentralisation, liberte et fraternite !"
echo ""
echo "Deutsch: Herzlichen Gluckwunsch! Ihr ProtocolGenesis-Knoten wurde erstellt. Sie sind jetzt Teil des Okosystems."
echo "Im Knoten konnen Sie Wallets verwalten, Transaktionen durchfuhren, das Netzwerk uberwachen und APIs direkt mit der ProtocolGenesis-App verbinden."
echo "Gemeinsam werden wir die Welt mit Dezentralisierung, Freiheit und Bruderlichkeit revolutionieren!"
echo "--------------------"


